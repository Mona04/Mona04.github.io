using UnrealBuildTool;
using System.Collections.Generic;

public class Portfolio_CppTarget : TargetRules
{
	public Portfolio_CppTarget( TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		DefaultBuildSettings = BuildSettingsVersion.V2;
		ExtraModuleNames.AddRange( new string[] { "Portfolio_Cpp" } );
	}
}

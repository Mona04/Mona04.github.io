#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "CCharacter.generated.h"

UENUM(BlueprintType)
enum class ETestEnum : uint8
{
	A, B, C
};

UENUM(BlueprintType)
namespace ETestEnum2
{
	enum Type { A, B, C };
}

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FDelegateEx);

UCLASS()
class PORTFOLIO_CPP_API ACCharacter : public ACharacter
{
	GENERATED_BODY()

private:
	UPROPERTY(VisibleDefaultsOnly)
		int bbb = 0;
protected:
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
		int aaa = 10;
	UPROPERTY(EditDefaultsOnly)
		TSubclassOf<ACharacter> bp_class;
	UPROPERTY(EditDefaultsOnly)
		FStringClassReference strref_class1;
	UPROPERTY(EditDefaultsOnly)
		FSoftClassPath strref_class2;
	UPROPERTY(EditDefaultsOnly)
		ETestEnum enum_test;
	UPROPERTY(EditDefaultsOnly)
		TEnumAsByte<ETestEnum2::Type> enum_test2;
	UPROPERTY()
		TArray<class UObject*> actors;

public:
	UPROPERTY(BlueprintAssignable)
		FDelegateEx OnDelegate;
	UPROPERTY(BlueprintAssignable, BlueprintCallable)
		FDelegateEx OnDelegate2;
public:
	ACCharacter();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void Tick(float DeltaTime) override;

	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
};

#include "CCharacter.h"
#include "Global.h"


ACCharacter::ACCharacter()
{
	PrimaryActorTick.bCanEverTick = true;
}

void ACCharacter::BeginPlay()
{
	Super::BeginPlay();
	
	PrintLine();
	FSoftClassPath strref_class(TEXT("Blueprint'/Game/02_Test/BP_EX_Actor_Object.BP_EX_Actor_Object_C'"));
	if (!!strref_class.TryLoadClass<AActor>())
	{
		auto actor = NewObject<UObject>(this, strref_class.TryLoadClass<AActor>(), "Name");
		//actor->ConditionalBeginDestroy();
		auto test_actor = GetWorld()->SpawnActor<AActor>(strref_class.TryLoadClass<AActor>());
		auto w_actor = FWeakObjectPtr(test_actor);
		PFCPP::Log(w_actor.Get());
		actors.Add(actor);
		GetWorld()->ForceGarbageCollection(true);  // normal_ptr is directing garbage after next GC
		FTimerDelegate on_sec = FTimerDelegate::CreateLambda([=]() {
			PFCPP::Log(w_actor.IsValid() ? "Valid!!" : "Invalid!!");
		});
		static FTimerHandle handle;
		GetWorld()->GetTimerManager().SetTimer(handle, on_sec, 1.f, false);
	}
}

void ACCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ACCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}


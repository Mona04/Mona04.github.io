#include "Util_Log.h"

DEFINE_LOG_CATEGORY(PFCPP_LOG);
//DEFINE_LOG_CATEGORY_STATIC(PFCPP_LOG, Display, All);

void PFCPP::Print(int32 value, int32 key, float duration, FColor color)
{
	GEngine->AddOnScreenDebugMessage(key, duration, color, FString::FromInt(value));
}

void PFCPP::Print(float value, int32 key, float duration, FColor color)
{
	GEngine->AddOnScreenDebugMessage(key, duration, color, FString::SanitizeFloat(value));
}

void PFCPP::Print(const FString& value, int32 key, float duration, FColor color)
{
	GEngine->AddOnScreenDebugMessage(key, duration, color, value);
}

void PFCPP::Print(const FVector& value, int32 key, float duration, FColor color)
{
	GEngine->AddOnScreenDebugMessage(key, duration, color, value.ToString());
}

void PFCPP::Print(const FRotator& value, int32 key, float duration, FColor color)
{
	GEngine->AddOnScreenDebugMessage(key, duration, color, value.ToString());
}

void PFCPP::Print(const UObject* value, int32 key, float duration, FColor color)
{
	FString str;

	if (!!value) str.Append(value->GetName());
	else str.Append("Input is Null Pointer.");

	GEngine->AddOnScreenDebugMessage(key, duration, color, str);
}

void PFCPP::Print(const FString& in_file_name, const FString& func_name, int32 line_num)
{
	int32 idx = 0;
	int32 length = in_file_name.Len() - 1;
	in_file_name.FindLastChar(L'\\', idx);
	FString file_name = in_file_name.Right(length - idx);

	GEngine->AddOnScreenDebugMessage(-1, 5, FColor::Red, FString::Printf(TEXT("%s, %s, %d"), *file_name, *func_name, line_num));
}

void PFCPP::Log(int32 value)
{
	//GLog->Log()
	UE_LOG(PFCPP_LOG, Display, L"%d", value);
}

void PFCPP::Log(float value)
{
	UE_LOG(PFCPP_LOG, Display, L"%f", value);
}

void PFCPP::Log(const FString& value)
{
	UE_LOG(PFCPP_LOG, Display, L"%s", *value);
}

void PFCPP::Log(const FVector& value)
{
	UE_LOG(PFCPP_LOG, Display, L"%s", *value.ToString());
}

void PFCPP::Log(const FRotator& value)
{
	UE_LOG(PFCPP_LOG, Display, L"%S", *value.ToString());
}

void PFCPP::Log(const UObject* value)
{
	FString str;

	if (!!value) str.Append(value->GetName());
	else str.Append("Input is Null Pointer.");

	UE_LOG(PFCPP_LOG, Display, L"%s", *str);
}

void PFCPP::Log(const FString& in_file_name, const FString& func_name, int32 line_num)
{
	int32 idx = 0;
	int32 length = in_file_name.Len() - 1;
	in_file_name.FindLastChar(L'\\', idx);
	FString file_name = in_file_name.Right(length - idx);

	UE_LOG(PFCPP_LOG, Display, L"%s", *FString::Printf(TEXT("%s, %s, %d"), *file_name, *func_name, line_num));
}


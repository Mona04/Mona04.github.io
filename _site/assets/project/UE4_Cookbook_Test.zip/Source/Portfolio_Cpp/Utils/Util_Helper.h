#pragma once
#include "CoreMinimal.h"
#include "UObject/ConstructorHelpers.h"
#include "Kismet/GameplayStatics.h"
#include "Particles/ParticleSystem.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "Animation/AnimMontage.h"

namespace PFCPP
{
	template<typename T>
	static void GetAsset(T** out, FString path)
	{
		ConstructorHelpers::FObjectFinder<T> meshFind(*path);
		*out = meshFind.Object;
	}

	template<typename T>
	static void GetAssetDynamic(T** out, FString path)
	{
		*out = Cast<T>(StaticLoadObject(T::StaticClass(), nullptr, *path));
	}

	template<typename T>
	static void GetClass(TSubclassOf<T>* outClass, FString path)
	{
		ConstructorHelpers::FClassFinder<T> finder(*path);
		if (finder.Succeeded())
			*outClass = finder.Class;
	}

	// Component
#pragma region
	template<typename T>
	static void CreateComponent(AActor* actor, T** outComp, FName name, USceneComponent* parentComp = nullptr)
	{
		*outComp = actor->CreateDefaultSubobject<T>(name);
		if (!!parentComp) {
			(*outComp)->SetupAttachment(parentComp);
		}
		else {
			actor->SetRootComponent(*outComp);
		}
	}

	template<typename T>
	static void CreateComponentOuter(AActor* actor, T** outComp, FName name, USceneComponent* parentComp = nullptr,
		FAttachmentTransformRules attachRule = FAttachmentTransformRules::KeepRelativeTransform)
	{
		*outComp = NewObject<T>(actor, name);
		if (!!outComp) (*outComp)->RegisterComponent();
		
		if (!!parentComp) {
			(*outComp)->AttachToComponent(parentComp, attachRule);
		}
		else {
			actor->SetRootComponent(*outComp);
		}
	}

	template<typename T>
	static void CreateActorComponent(AActor* actor, T** outComp, FName name)
	{
		*outComp = actor->CreateDefaultSubobject<T>(name);
	}

	template<typename T>
	static T* GetComponent(AActor* InActor)
	{
		return Cast<T>(InActor->GetComponentByClass(T::StaticClass()));
	}

	template<typename T>
	static T* GetComponent(AActor* actor, FString name)
	{
		TArray<T*> components;
		actor->GetComponents<T>(components);
		for (T* component : components)
		{
			if (component->GetName() == name)
				return component;
		}
		return nullptr;
	}
#pragma endregion

	// Actor
#pragma region
	template<typename T>
	static T* FindActor(UWorld* world, int32 idx = 0)
	{
		TArray<AActor*> actors;
		UGameplayStatics::GetAllActorsOfClass(world, T::StaticClass(), actors);
		//GetWorld()->GetCurrentLevel()->Actors

		if (actors.Num() < idx + 1)
			return nullptr;

		return Cast<T>(actors[idx]);
	}

	template<typename T>
	static void FindActors(UWorld* world, TArray<AActor*>& out_actors)
	{
		TArray<AActor*> actors;
		UGameplayStatics::GetAllActorsOfClass(world, T::StaticClass(), actors);

		for (AActor* actor : actors)
		{
			T* obj = Cast<T>(actor);
			if (!!obj)
				out_actors.Add(obj);
		}
	}
#pragma endregion

	// ==== Miscellaneous ==============================================

	static FString GetStringFromEnumByIndex(FString enumName, int32 idx)
	{
		// Find any project, SGA3_API is project too.
		// Like UClass, UEnum is type of enum;
		UEnum* ptr = FindObject<UEnum>(ANY_PACKAGE, *enumName, true);
		return ptr->GetNameStringByIndex(idx);
	}

	template<typename T>
	static FString GetStringFromEnumByIndex(int32 idx)
	{
		return StaticEnum<T>()->GetNameStringByIndex(idx);
	}


	static float GetMontageLength(class UAnimMontage* montage, float play_ratio = 1.f)
	{
		return montage->GetPlayLength() / (play_ratio * montage->RateScale);
	}

	// ========================================================================
	// Particle & Niagara
	// ========================================================================

	static void PlayEffectAtLocation(UWorld* world, UFXSystemAsset* effect, FTransform& transform)
	{
		UParticleSystem* particle = Cast<UParticleSystem>(effect);
		if (!!particle)
		{
			UGameplayStatics::SpawnEmitterAtLocation(world, particle, transform);
			return;
		}

		UNiagaraSystem* niagara = Cast<UNiagaraSystem>(effect);
		if (!!niagara)
		{
			UNiagaraFunctionLibrary::SpawnSystemAtLocation(world, niagara, transform.GetLocation(), transform.GetRotation().Rotator(), transform.GetScale3D());
			return;
		}
	}

	static void PlayEffectAttached(UFXSystemAsset* effect, USceneComponent* attached_comp, const FName& attached_name, const FTransform& trans, EAttachLocation::Type location_type, bool auto_destroy = true)
	{
		UParticleSystem* particle = Cast<UParticleSystem>(effect);
		if (!!particle)
		{
			UGameplayStatics::SpawnEmitterAttached(particle, attached_comp, attached_name,
				trans.GetLocation(), trans.GetRotation().Rotator(), location_type, auto_destroy);
			return;
		}

		UNiagaraSystem* niagara = Cast<UNiagaraSystem>(effect);
		if (!!niagara)
		{
			UNiagaraFunctionLibrary::SpawnSystemAttached(niagara, attached_comp, attached_name,
				trans.GetLocation(), trans.GetRotation().Rotator(), location_type, auto_destroy);
			return;
		}
	}

	// ========================================================================
	// Debug & Test
	// ========================================================================

	static FLinearColor GetRandomColor()
	{
		return FLinearColor(
			UKismetMathLibrary::RandomFloatInRange(0, 1),
			UKismetMathLibrary::RandomFloatInRange(0, 1),
			UKismetMathLibrary::RandomFloatInRange(0, 1),
			1
		);
	}
};
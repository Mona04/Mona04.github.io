#pragma once
#include "Logging/LogMacros.h"

#define PrintLine() {PFCPP::Print(__FILE__, __FUNCTION__, __LINE__);}
#define LogLine() {PFCPP::Log(__FILE__, __FUNCTION__, __LINE__);}

DECLARE_LOG_CATEGORY_EXTERN(PFCPP_LOG, Display, All);

namespace PFCPP
{
	void Print(int32 value, int32 key = -1, float duration = 10, FColor color = FColor::Blue);
	void Print(float value, int32 key = -1, float duration = 10, FColor color = FColor::Blue);
	void Print(const FString& value, int32 key = -1, float duration = 10, FColor color = FColor::Blue);
	void Print(const FVector& value, int32 key = -1, float duration = 10, FColor color = FColor::Blue);
	void Print(const FRotator& value, int32 key = -1, float duration = 10, FColor color = FColor::Blue);
	void Print(const UObject* value, int32 key = -1, float duration = 10, FColor color = FColor::Blue);
	void Print(const FString& InFileName, const FString& InFuncName, int32 InLineNumber);

	void Log(int32 value);
	void Log(float value);
	void Log(const FString& value);
	void Log(const FVector& value);
	void Log(const FRotator& value);
	void Log(const UObject* value);
	void Log(const FString& InFileName, const FString& InFuncName, int32 InLineNumber);
}
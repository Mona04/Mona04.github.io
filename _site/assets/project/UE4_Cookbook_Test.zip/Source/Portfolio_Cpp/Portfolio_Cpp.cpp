#include "Portfolio_Cpp.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Portfolio_Cpp, "Portfolio_Cpp" );

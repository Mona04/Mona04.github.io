#pragma once

#include "CoreMinimal.h"
#include "Components/Widget.h"
#include "SEX_CompoundWidget.h"
#include "Ex_CompoundWidget.generated.h"

DECLARE_DYNAMIC_DELEGATE_RetVal(FString, FGetString);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FButtonClicked);

UCLASS()
class PORTFOLIO_CPP_API UEx_CompoundWidget : public UWidget
{
	GENERATED_BODY()
	
public:
	UPROPERTY(BlueprintAssignable)
		FButtonClicked OnButtonClicked;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString label;
	UPROPERTY()
		FGetString labelDelegate;

public:
	UEx_CompoundWidget();
	
	virtual void SynchronizeProperties() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;

public:
	FReply OnButtonClicked_Reply();

protected:
	TSharedPtr<SEX_CompoundWidget> ex_slate;
};

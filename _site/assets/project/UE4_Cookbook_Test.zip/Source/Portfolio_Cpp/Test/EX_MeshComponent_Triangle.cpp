#include "Test/EX_MeshComponent_Triangle.h"
#include "Global.h"

UEX_MeshComponent_Triangle::UEX_MeshComponent_Triangle()
{
	PFCPP::GetAsset(&material, "MaterialInstanceConstant'/Game/01_UsedAsset/Material/Basic/M_Mesh_Inst.M_Mesh_Inst'");
	vertices.Add({ 50, 0, 0 });
	vertices.Add({ 0, 50, 0 });
	vertices.Add({ 0, 0, 50 });
	indices = { 0, 1 ,2 };
}

FPrimitiveSceneProxy* UEX_MeshComponent_Triangle::CreateSceneProxy()
{
	return new FMySceneProxy(this);
}


void FMySceneProxy::FMyVertexBuffer::InitRHI()
{
	const int32 size = vertices.Num() * sizeof(FVector);
	
	FRHIResourceCreateInfo info;
	VertexBufferRHI = RHICreateVertexBuffer(size, BUF_Static, info);

	void* data = RHILockVertexBuffer(VertexBufferRHI, 0, size, RLM_WriteOnly);
	FMemory::Memcpy(data, vertices.GetData(), size);
	RHIUnlockVertexBuffer(VertexBufferRHI);
}

void FMySceneProxy::FMyIndexBuffer::InitRHI()
{
	const int32 size = indices.Num() * sizeof(uint32);

	FRHIResourceCreateInfo info;
	IndexBufferRHI = RHICreateIndexBuffer(sizeof(uint32), size, BUF_Static, info);

	void* data = RHILockIndexBuffer(IndexBufferRHI, 0, size, RLM_WriteOnly);
	FMemory::Memcpy(data, indices.GetData(), size);
	RHIUnlockIndexBuffer(IndexBufferRHI);
}

FMySceneProxy::FMySceneProxy(UEX_MeshComponent_Triangle* Component)
	: FPrimitiveSceneProxy(Component)
	, material(Component->material), indices(Component->indices)
{
	vertexBuffer = FMyVertexBuffer();
	indexBuffer = FMyIndexBuffer();
	for (FVector Vertex : Component->vertices)
		vertices.Add(FDynamicMeshVertex(Vertex));
}

FPrimitiveViewRelevance FMySceneProxy::GetViewRelevance(const FSceneView* view) const
{
	FPrimitiveViewRelevance r;
	r.bDynamicRelevance = true;
	r.bDrawRelevance = true;
	r.bNormalTranslucency = true;
	return r;
}

void FMySceneProxy::GetDynamicMeshElements(const TArray<const FSceneView*>& views, const FSceneViewFamily& viewFamily, uint32 visibilityMap, FMeshElementCollector& collector) const
{
	if (!material) return;
	
	for (int32 i = 0; i < views.Num(); i++)
	{
		FDynamicMeshBuilder meshBuilder(ERHIFeatureLevel::SM5);
		if (vertices.Num() == 0) return;
		meshBuilder.AddVertices(vertices);
		meshBuilder.AddTriangles(indices);
		meshBuilder.GetMesh(FMatrix::Identity, 
			new FColoredMaterialRenderProxy(material->GetRenderProxy(), FLinearColor::Gray),
			GetDepthPriorityGroup(views[i]), true, true, i, collector);
	}
}
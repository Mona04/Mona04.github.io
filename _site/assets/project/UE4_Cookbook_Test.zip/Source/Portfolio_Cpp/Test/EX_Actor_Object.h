#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Ex_Interface.h"
#include "EX_Actor_Object.generated.h"

DECLARE_DELEGATE(FDelegateEx);
DECLARE_DYNAMIC_DELEGATE(FDelegateDynamicEx);
DECLARE_MULTICAST_DELEGATE(FDelegateMultiEx);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FDelegateMultiDynamicEx);

DECLARE_DELEGATE_OneParam(FDelegate1ParamEx, float);

class NativeCPP
{
public:
	void PrintLog();
	static void PrintStaticLog();
};

UENUM(BlueprintType)
enum class EEnumEx : uint8
{
	A, B, C, MAX
};

UCLASS(Blueprintable, BlueprintType)
class PORTFOLIO_CPP_API AEX_Actor_Object : public AActor, public IEX_Interface
{
	GENERATED_BODY()

public:
	DECLARE_EVENT(AEX_Actor_Object, FEventEx);

public:
	UPROPERTY(BlueprintAssignable, BlueprintCallable)
		FDelegateEx OnDelegateEx;
	UPROPERTY()
		FDelegateDynamicEx OnDelegateDynamicEx;
	FDelegateMultiEx OnDelegateMultiEx;
	UPROPERTY(BlueprintAssignable, BlueprintCallable)
		FDelegateMultiDynamicEx OnDelegateMultiDynamicEx;
	FDelegate1ParamEx OnDelegate1ParamEx;

	FEventEx OnEventEx;

protected:
	UPROPERTY(VisibleDefaultsOnly)
		class UStaticMeshComponent* mesh_comp;
	UPROPERTY(VisibleDefaultsOnly)
		class UMeshComponent* my_mesh_comp;

	UPROPERTY(EditDefaultsOnly)
		class UStaticMesh* mesh;
	UPROPERTY(EditDefaultsOnly)
		class UMaterialInstance* material;

	UPROPERTY(EditAnywhere)
		int my_array[(int32)EEnumEx::C];

	UPROPERTY(BlueprintReadWrite)
		int aaa;

public:	
	AEX_Actor_Object();
	virtual ~AEX_Actor_Object();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void Tick(float DeltaTime) override;

	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void OnConstruction(const FTransform& Transform) override;

public:
	UFUNCTION()
		void PrintLog();

	void PrintLog2(float v, bool b);
	
};

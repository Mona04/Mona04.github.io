#include "Test/SEX_CompoundWidget.h"
#include "SlateOptMacros.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Text/STextBlock.h"

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
void SEX_CompoundWidget::Construct(const FArguments& InArgs)
{
	label = InArgs._label;
	OnButtonClicked = InArgs._OnButtonClicked;
	ChildSlot.VAlign(VAlign_Center)
	[
		SNew(SButton)
		.OnClicked(OnButtonClicked.Get())
		.Content()
		[
			SNew(STextBlock)
			.Text_Lambda([this]() {return FText::FromString(label.Get()); })
		]
	];
}
END_SLATE_FUNCTION_BUILD_OPTIMIZATION

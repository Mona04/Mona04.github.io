#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"

class PORTFOLIO_CPP_API SEX_CompoundWidget : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SEX_CompoundWidget)
		: _label(TEXT("Default Value"))
		, _OnButtonClicked()
	{}
	SLATE_ATTRIBUTE(FString, label);
	SLATE_ATTRIBUTE(FOnClicked, OnButtonClicked);
	SLATE_END_ARGS();

	void Construct(const FArguments& InArgs);

public:
	TAttribute<FString> label;
	TAttribute<FOnClicked> OnButtonClicked;
};

#include "Test/EX_HUD.h"

#include "Engine/Canvas.h"

AEx_HUD::AEx_HUD()
{
	int a = 0;
}

void AEx_HUD::DrawHUD()
{
	Super::DrawHUD();

	Canvas->DrawText(GEngine->GetSmallFont(), TEXT("Test string to be printed to screen"), 10, 10);
	FCanvasBoxItem progressBar(FVector2D(5, 25), FVector2D(100, 5));
	Canvas->DrawItem(progressBar);
	DrawRect(FLinearColor::Blue, 5, 25, 100, 5);
}

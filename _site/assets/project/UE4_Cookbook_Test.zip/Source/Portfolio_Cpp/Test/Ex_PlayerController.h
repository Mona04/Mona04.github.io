#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "Ex_PlayerController.generated.h"


UCLASS()
class PORTFOLIO_CPP_API AEx_PlayerController : public APlayerController
{
	GENERATED_BODY()
	
public:
	UPROPERTY()
		FTimerHandle hud_toggle_timer;
	
	TSharedPtr<class SVerticalBox> widget;
public:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type reason) override;
};

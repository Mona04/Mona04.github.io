#pragma once

#include "CoreMinimal.h"
#include "Components/MeshComponent.h"
#include "VertexFactory.h"
#include "DynamicMeshBuilder.h"
#include "EX_MeshComponent_Triangle.generated.h"

UCLASS(ClassGroup = "Ex", meta = (BlueprintSpawnableComponent))
class PORTFOLIO_CPP_API UEX_MeshComponent_Triangle : public UMeshComponent
{
	GENERATED_BODY()
	
public:
	UEX_MeshComponent_Triangle();
	virtual class FPrimitiveSceneProxy* CreateSceneProxy() override;

public:
	TArray<FVector> vertices;
	TArray<uint32>  indices;
	UPROPERTY(EditAnywhere)
		class UMaterialInterface* material;
};

class FMySceneProxy : public FPrimitiveSceneProxy
{
private:
	class FMyVertexBuffer : public FVertexBuffer
	{
	public:
		TArray<FVector> vertices;
		// Rendering Hardware Interface 
		virtual void InitRHI() override;
	};

	class FMyIndexBuffer : public FIndexBuffer
	{
	public:
		TArray<uint32> indices;
		virtual void InitRHI() override;
	};

public:
	FMySceneProxy(UEX_MeshComponent_Triangle* Component);
	virtual FPrimitiveViewRelevance GetViewRelevance(const FSceneView* view) const override;
	virtual void GetDynamicMeshElements(const TArray<const FSceneView*>& views, const FSceneViewFamily& viewFamily, uint32 visibilityMap, FMeshElementCollector& collector) const override;
	virtual uint32 GetMemoryFootprint() const override { return sizeof(*this); }
	virtual SIZE_T GetTypeHash() const override { return 1; };
	virtual ~FMySceneProxy() {};
private:
	UPROPERTY()
		UMaterialInterface* material;
	TArray<FDynamicMeshVertex> vertices;
	TArray<uint32> indices;
	FMyVertexBuffer vertexBuffer;
	FMyIndexBuffer indexBuffer;
};
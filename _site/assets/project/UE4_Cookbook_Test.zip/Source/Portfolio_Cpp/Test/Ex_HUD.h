#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "Ex_Hud.generated.h"

UCLASS()
class PORTFOLIO_CPP_API AEx_HUD : public AHUD
{
	GENERATED_BODY()

public:
	AEx_HUD();

	virtual void DrawHUD() override;

};

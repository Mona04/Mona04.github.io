#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "EX_Interface.generated.h"

UINTERFACE(MinimalAPI)
class UEX_Interface : public UInterface
{
	GENERATED_BODY()
};


class PORTFOLIO_CPP_API IEX_Interface
{
	GENERATED_BODY()

public:
	IEX_Interface();

public:
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent, Category = "Test")
		void Happy();
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent, Category = "Test")
		bool Happy2();
};

#include "Test/Ex_CompoundWidget.h"


UEx_CompoundWidget::UEx_CompoundWidget()
	: label(TEXT("Default Text"))
{

}

TSharedRef<SWidget> UEx_CompoundWidget::RebuildWidget()
{
	ex_slate = SNew(SEX_CompoundWidget)
		.OnButtonClicked(BIND_UOBJECT_DELEGATE(FOnClicked, OnButtonClicked_Reply));
	return ex_slate.ToSharedRef();
}

void UEx_CompoundWidget::SynchronizeProperties()
{
	Super::SynchronizeProperties();

	ex_slate->label = OPTIONAL_BINDING(FString, label);
}

void UEx_CompoundWidget::ReleaseSlateResources(bool bReleaseChildren)
{
	ex_slate.Reset();
}

FReply UEx_CompoundWidget::OnButtonClicked_Reply()
{
	OnButtonClicked.Broadcast();
	return FReply::Handled();
}





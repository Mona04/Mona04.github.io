#include "Test/Ex_PlayerController.h"
#include "SlateBasics.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Text/STextBlock.h"

void AEx_PlayerController::BeginPlay()
{
	Super::BeginPlay();

	 widget = SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(SButton)
			.Content()
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Text Button")))
			]
		];


	GEngine->GameViewport->AddViewportWidgetForPlayer(GetLocalPlayer(), widget.ToSharedRef(), 1);
	
	if (!GetWorld()) return;
	GetWorld()->GetTimerManager().SetTimer(
		hud_toggle_timer,
		FTimerDelegate::CreateLambda(
			[this]()
			{
				if (this->widget->GetVisibility().IsVisible())
					this->widget->SetVisibility(EVisibility::Hidden);
				else
					this->widget->SetVisibility(EVisibility::Visible);
			}
		), 1 , true
	);
}

void AEx_PlayerController::EndPlay(const EEndPlayReason::Type reason)
{
	Super::EndPlay(reason);
	// �̰� ���ŵ� �� timer �� ���������� ��۸������Ͷ� �����ؾ���
	GetWorld()->GetTimerManager().ClearTimer(hud_toggle_timer);
}
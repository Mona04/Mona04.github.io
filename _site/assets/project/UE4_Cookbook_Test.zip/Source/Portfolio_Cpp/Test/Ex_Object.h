#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Ex_Object.generated.h"

UCLASS(BlueprintType)
class PORTFOLIO_CPP_API UEx_Object : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Custom Asset")
		FString name;
	UPROPERTY(EditAnywhere, Category = "Custom Asset")
		FLinearColor color;
};

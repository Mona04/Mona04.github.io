#include "EX_Actor_Object.h"
#include "Global.h"
#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInstanceConstant.h"
#include "EngineUtils.h"
#include "Test/EX_MeshComponent_Triangle.h"

AEX_Actor_Object::AEX_Actor_Object()
{
	PrimaryActorTick.bCanEverTick = true;
	mesh_comp = CreateDefaultSubobject<UStaticMeshComponent>("Mesh");
	mesh_comp->SetWorldScale3D({ 0.1f, 0.1f, 0.1f });
	RootComponent = mesh_comp;
	my_mesh_comp = CreateDefaultSubobject<UEX_MeshComponent_Triangle>("MeshTriangle");
	my_mesh_comp->SetupAttachment(RootComponent);
	my_mesh_comp->SetWorldScale3D({ 100.f, 100.f, 100.f });
	ConstructorHelpers::FObjectFinder<UStaticMesh> meshFind(TEXT("StaticMesh'/Game/01_UsedAsset/Meshes/BasicMesh/Cube.Cube'"));
	mesh_comp->SetStaticMesh(meshFind.Object);

	PFCPP::Log("AEX_Actor_Object Constructed");
}

AEX_Actor_Object::~AEX_Actor_Object()
{
	PFCPP::Log("AEX_Actor_Object Destoryed");
}

void AEX_Actor_Object::BeginPlay()
{
	Super::BeginPlay();

	OnDelegateEx.BindUObject(this, &AEX_Actor_Object::PrintLog);
	static NativeCPP native_class;
	OnDelegateMultiEx.AddUFunction(this, "PrintLog");
	OnDelegateMultiEx.AddStatic(&NativeCPP::PrintStaticLog);
	OnDelegateMultiEx.AddRaw(&native_class, &NativeCPP::PrintLog);
	OnDelegateDynamicEx.BindUFunction(this, "PrintLog");

	OnDelegateMultiDynamicEx.AddDynamic(this, &AEX_Actor_Object::PrintLog);

	OnDelegate1ParamEx.BindUObject(this, &AEX_Actor_Object::PrintLog2, true);

	FTimerDelegate on_sec = FTimerDelegate::CreateLambda([&]() {
		if (IsValid(this) == false) return;
		PFCPP::Log("Delegate On");
		OnDelegateEx.ExecuteIfBound();
		PFCPP::Log("Delegate Dynamic On");
		OnDelegateDynamicEx.ExecuteIfBound();
		PFCPP::Log("Delegate Multi On");
		OnDelegateMultiEx.Broadcast();
		PFCPP::Log("Delegate MultiDynaimc On");
		OnDelegateMultiDynamicEx.Broadcast();
		PFCPP::Log("Delegate TwoParams On");
		OnDelegate1ParamEx.ExecuteIfBound(1.23);

		int counter = 0;
		for (TActorIterator<AActor> iter(GetWorld()); !!iter; ++iter)
		{
			if(iter->GetClass()->ImplementsInterface(UEX_Interface::StaticClass()))
				counter++;
		}
		PFCPP::Log(FString::Printf(L"IEx_Interface Num is %d", counter));
		
		Execute_Happy(this);

		});
	static FTimerHandle handle;
	GetWorld()->GetTimerManager().SetTimer(handle, on_sec, 1.f, false);
}

void AEX_Actor_Object::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AEX_Actor_Object::PrintLog()
{
	PFCPP::Log("AEX_Actor_Object Logging");
}

void AEX_Actor_Object::PrintLog2(float v, bool b)
{
	b ?
	PFCPP::Log(FString::Printf(L"AEX_Actor_Object Logging %f True", v))
	:
	PFCPP::Log(FString::Printf(L"AEX_Actor_Object Logging %f False", v));
}

void AEX_Actor_Object::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (!!PropertyChangedEvent.Property)
	{
		const FName name(PropertyChangedEvent.Property->GetName());
		if (name == GET_MEMBER_NAME_CHECKED(AEX_Actor_Object, my_array))
		{
			PFCPP::Print(my_array[0]);
		}
		if (name == GET_MEMBER_NAME_CHECKED(AEX_Actor_Object, aaa))
		{
			PFCPP::Print(aaa);
		}
	}
}

void AEX_Actor_Object::OnConstruction(const FTransform& Transform)
{
	PFCPP::Print("Construction");
}


// ========== NativeCpp ==================================================

void NativeCPP::PrintStaticLog()
{
	PFCPP::Log("NativeCPP Static Logging");
}

void NativeCPP::PrintLog()
{
	PFCPP::Log("NativeCPP Raw Logging");
}

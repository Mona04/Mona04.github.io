#include "Test/EX_Interface.h"


IEX_Interface::IEX_Interface()
{

}
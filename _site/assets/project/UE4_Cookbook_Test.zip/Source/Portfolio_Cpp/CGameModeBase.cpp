#include "CGameModeBase.h"
#include "Global.h"
#include "GameFramework/PlayerInput.h"
#include "GameFramework/HUD.h"

#include "Test/Ex_HUD.h"
#include "Test/Ex_PlayerController.h"

ACGameModeBase::ACGameModeBase()
{
	//PFCPP::GetClass(&DefaultPawnClass, L"Blueprint'/Game/02_BP/02_Character/BP_CPlayer.BP_CPlayer_C'");
	//PFCPP::GetClass(&HUDClass, L"Class'/Script/Portfolio_Cpp.Ex_HUD_C'");
	HUDClass = AEx_HUD::StaticClass();
	PlayerControllerClass = AEx_PlayerController::StaticClass();
	UPlayerInput::AddEngineDefinedAxisMapping(FInputAxisKeyMapping("MoveRight", EKeys::Left));
	UPlayerInput::AddEngineDefinedAxisMapping(FInputAxisKeyMapping("MoveUp", EKeys::Up));
	UPlayerInput::AddEngineDefinedActionMapping(FInputActionKeyMapping("LeftClick", EKeys::RightMouseButton));
}

#include "Portfolio_Cpp_Editor.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_GAME_MODULE(FPFCppEditorModule, Portfolio_Cpp_Editor);

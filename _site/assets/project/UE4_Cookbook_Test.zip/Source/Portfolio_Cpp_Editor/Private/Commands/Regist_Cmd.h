#pragma once

#include "CoreMinimal.h"

class Regist_Cmd
{
public:
	static void StartupModule();
	static void ShutdownModule();

private:
	static struct IConsoleCommand* log_test;
	static struct IConsoleCommand* log_user_specified;
};

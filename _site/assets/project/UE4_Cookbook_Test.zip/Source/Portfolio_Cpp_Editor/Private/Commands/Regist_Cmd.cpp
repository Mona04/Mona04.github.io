#include "Commands/Regist_Cmd.h"

#include "HAL/IConsoleManager.h"

IConsoleCommand* Regist_Cmd::log_test;
IConsoleCommand* Regist_Cmd::log_user_specified;

void Regist_Cmd::StartupModule()
{
	log_test = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("LogTest"),
		TEXT("test"),
		FConsoleCommandDelegate::CreateLambda(
			[]() {
				UE_LOG(LogTemp, Display, TEXT("Display Test Command")); 
			}),
		ECVF_Default
	);

	log_user_specified = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("LogUserSpecified"),
		TEXT("test"),
		FConsoleCommandWithArgsDelegate::CreateLambda(
			[&](const TArray<FString>& args) {
				FString log_datas;
				for (FString arg : args)
				{
					log_datas += arg;
					log_datas.AppendChar(' ');
				}
				UE_LOG(LogTemp, Display, TEXT("%s"), *log_datas);
			}
		),
		ECVF_Default
	);
}

#define Unregist(p) { if(!!p){ IConsoleManager::Get().UnregisterConsoleObject(p); p = nullptr;} }

void Regist_Cmd::ShutdownModule()
{
	Unregist(log_test);
	Unregist(log_user_specified);
}
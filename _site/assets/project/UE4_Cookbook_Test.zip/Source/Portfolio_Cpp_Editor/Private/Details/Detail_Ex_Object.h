#pragma once

#include "CoreMinimal.h"
#include "IDetailCustomization.h"
#include "DetailLayoutBuilder.h"
#include "DetailCategoryBuilder.h"
#include "Widgets/Colors/SColorPicker.h"

#include "DetailWidgetRow.h"
#include "Test/Ex_Object.h"


class Detail_Ex_Object : public IDetailCustomization
{
public:
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;

	TWeakObjectPtr<UEx_Object> asset;

public:
	static TSharedRef<class IDetailCustomization> MakeInstance()
	{
		return MakeShareable(new Detail_Ex_Object);
	}

	static void StartupModule(FPropertyEditorModule& module)
	{
		module.RegisterCustomClassLayout(
			UEx_Object::StaticClass()->GetFName(),
			FOnGetDetailCustomizationInstance::CreateStatic(&Detail_Ex_Object::MakeInstance)
		);
	}

	static void ShutdownModule(FPropertyEditorModule& module)
	{
		module.UnregisterCustomClassLayout(UEx_Object::StaticClass()->GetFName());
	}
};

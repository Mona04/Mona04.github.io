#include "Details/Detail_Ex_Object.h"

void Detail_Ex_Object::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	const TArray<TWeakObjectPtr<UObject>>& selectedObjects = DetailBuilder.GetDetailsView()->GetSelectedObjects();
	
	for (int32 i = 0; !asset.IsValid() && i < selectedObjects.Num(); i++)
	{
		const TWeakObjectPtr<UObject>& cur = selectedObjects[i];
		if (cur.IsValid())
			asset = Cast<UEx_Object>(cur.Get());
	}
	
	DetailBuilder.EditCategory("Custom Category", FText::GetEmpty(), ECategoryPriority::Important)
		.AddCustomRow(FText::GetEmpty())
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot().VAlign(VAlign_Center)
		[
			SNew(SColorPicker)
			.OnColorCommitted(FOnLinearColorValueChanged::CreateLambda(
				[&](FLinearColor in) { asset->color = in; }
			))
		]
		];

}
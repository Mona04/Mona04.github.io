#include "Extenders/Extend_Toolbar.h"
#include "PFCPP_Command.h"

FExtend_Toolbar::FExtend_Toolbar()
{
}

FExtend_Toolbar::~FExtend_Toolbar()
{
}

void FExtend_Toolbar::StartupModule(TSharedPtr<FExtensibilityManager> manager, TSharedPtr<FUICommandList> cmdList)
{
	extender = MakeShareable(new FExtender());
	extension = extender->AddToolBarExtension(
		"Compile",
		EExtensionHook::Before,
		cmdList,
		FToolBarExtensionDelegate::CreateRaw(this, &FExtend_Toolbar::AddExtension)
	);

	manager->AddExtender(extender);
}

void FExtend_Toolbar::ShutdownModule()
{
	extender->RemoveExtension(extension.ToSharedRef());
	extension.Reset();
	extender.Reset();
}

void FExtend_Toolbar::AddExtension(FToolBarBuilder& builder)
{
	FSlateIcon iconBrush = FSlateIcon(FEditorStyle::GetStyleSetName(), "LevelEditor.ViewOptions", "LevelEditor.ViewOption.Small");

	builder.AddToolBarButton(
		FPFCPP_Command::Get().mybutton, NAME_None,
		FText::FromString("My Button"),
		FText::FromString("Click me to display a message"),
		iconBrush, NAME_None);
}

void FExtend_Toolbar::MyButton_Clicked()
{
	TSharedRef<SWindow> custom_window = SNew(SWindow)
		.Title(FText::FromString(TEXT("Custom Window")))
		.ClientSize(FVector2D(800, 400)).SupportsMinimize(false).SupportsMinimize(false)
		[
			SNew(SVerticalBox)
			+SVerticalBox::Slot().HAlign(HAlign_Center).VAlign(VAlign_Center)
			[
				SNew(STextBlock).Text(FText::FromString(TEXT("Hello from Slate")))
			]
		];

	IMainFrameModule& main_frame_module = FModuleManager::LoadModuleChecked<IMainFrameModule>(TEXT("MainFrame"));

	if (main_frame_module.GetParentWindow().IsValid())
	{
		FSlateApplication::Get().AddWindowAsNativeChild(custom_window, main_frame_module.GetParentWindow().ToSharedRef());
	}
	else {
		FSlateApplication::Get().AddWindow(custom_window);
	}
}
#include "Extenders/Extend_Menu.h"
#include "PFCPP_Command.h"

void FExtend_Menu::StartupModule(TSharedPtr<FExtensibilityManager> manager, TSharedPtr<FUICommandList> cmdList)
{
	extender = MakeShareable(new FExtender());
	extension = extender->AddMenuExtension(
		FName(*NSLOCTEXT("UnrealEditor", "WorkspaceMenu_LevelEditorCategory", "Level Editor").ToString().Replace(TEXT(" "), TEXT(""))),
		EExtensionHook::Before,
		cmdList,
		FMenuExtensionDelegate::CreateRaw(this, &FExtend_Menu::AddExtension)
	);

	manager->AddExtender(extender);
}

void FExtend_Menu::ShutdownModule()
{

}

void FExtend_Menu::AddExtension(FMenuBuilder& builder)
{
	FSlateIcon iconBrush = FSlateIcon(FEditorStyle::GetStyleSetName(), "LevelEditor.ViewOptions", "LevelEditor.ViewOptions.Small");
	builder.AddMenuEntry(FPFCPP_Command::Get().mybutton);
}
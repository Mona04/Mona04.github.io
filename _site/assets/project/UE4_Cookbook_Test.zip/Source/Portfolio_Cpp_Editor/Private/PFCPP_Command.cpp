#include "PFCPP_Command.h"

FPFCPP_Command::FPFCPP_Command() 
	: TCommands(FName(TEXT("FPFCPP_Command")), FText::FromString("Custom Command"), NAME_None, FEditorStyle::GetStyleSetName())
{
}

FPFCPP_Command::~FPFCPP_Command()
{
}

void FPFCPP_Command::RegisterCommands()
{
#define LOCTEXT_NAMESPACE ""
	UI_COMMAND(mybutton, "Custom Cmd", "Compact Command Button", EUserInterfaceActionType::Button, FInputGesture());
#undef LOCTEXT_NAMESPACE
}
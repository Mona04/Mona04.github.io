#pragma once
#include "CoreMinimal.h"
#include "AssetTypeActions_Base.h"
#include "AssetTypeCategories.h"

#include "Framework/Commands/UIAction.h"
#include "Test/Ex_Object.h"

#define LOCTEXT_NAMESPACE ""

static EAssetTypeCategories::Type MY_AssetCategory;

class FATA_UEx_Object : public FAssetTypeActions_Base {
public:
	virtual FText GetName() const override { return LOCTEXT("Ex_Object", "My Ex_Object"); }
	virtual uint32 GetCategories() override { return MY_AssetCategory; }
	virtual FColor GetTypeColor() const override { return FColor(127, 255, 255); }
	virtual FText GetAssetDescription(const FAssetData& AssetData) const override { return LOCTEXT("Ex_Object", "Ex_Object description."); }
	virtual UClass* GetSupportedClass() const override { return UEx_Object::StaticClass(); }

	virtual bool HasActions(const TArray<UObject*>& InObjects) const override { return true; }
	virtual void GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder) override
	{
		MenuBuilder.AddMenuEntry(
			FText::FromString("CustomAssetAction"),
			FText::FromString("Action for CustomAssetAction"),
			FSlateIcon(FEditorStyle::GetStyleSetName(), "LevelEditor.ViewOptions"),
			FUIAction(FExecuteAction::CreateRaw(this, &FATA_UEx_Object::Clicked), FCanExecuteAction())
		);
	}

	virtual void GetActions(const TArray<UObject*>& InObjects, FToolMenuSection& Section) override {}

	void Clicked();
};

class PORTFOLIO_CPP_EDITOR_API Regist_Asset
{
public:
	static void StartupModule();
	static void ShutdownModule();

	static TArray<TSharedPtr<IAssetTypeActions>> actions;
};

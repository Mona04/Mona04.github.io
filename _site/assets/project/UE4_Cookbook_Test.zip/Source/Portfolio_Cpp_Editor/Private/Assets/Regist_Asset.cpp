#include "Regist_Asset.h"

#include "Interfaces/IMainFrameModule.h"
#include "AssetToolsModule.h"

void FATA_UEx_Object::Clicked()
{
	TSharedRef<SWindow> custom_window = SNew(SWindow)
		.Title(FText::FromString(TEXT("Custom Window")))
		.ClientSize(FVector2D(800, 400)).SupportsMinimize(false).SupportsMinimize(false)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot().HAlign(HAlign_Center).VAlign(VAlign_Center)
		[
			SNew(STextBlock).Text(FText::FromString(TEXT("Hello from Slate")))
		]
		];

	IMainFrameModule& main_frame_module = FModuleManager::LoadModuleChecked<IMainFrameModule>(TEXT("MainFrame"));

	if (main_frame_module.GetParentWindow().IsValid())
	{
		FSlateApplication::Get().AddWindowAsNativeChild(custom_window, main_frame_module.GetParentWindow().ToSharedRef());
	}
	else {
		FSlateApplication::Get().AddWindow(custom_window);
	}
}

TArray<TSharedPtr<IAssetTypeActions>> Regist_Asset::actions;

void Regist_Asset::StartupModule()
{
	IAssetTools& asset_tool_module = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	MY_AssetCategory = asset_tool_module.RegisterAdvancedAssetCategory(FName(TEXT("CustomCategory")), LOCTEXT("CustomCategory", "Custom Category"));
	{
		TSharedRef<IAssetTypeActions> action = MakeShareable(new FATA_UEx_Object);
		asset_tool_module.RegisterAssetTypeActions(action);
		actions.Add(action);
	}
}

void Regist_Asset::ShutdownModule()
{
	//IAssetTools& asset_tool_module = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	//for (auto action : actions)
	//	asset_tool_module.UnregisterAssetTypeActions(action.ToSharedRef());
}

#pragma once

#include "CoreMinimal.h"
#include "Factories/Factory.h"
#include "Ex_Asset_Factory.generated.h"


UCLASS()
class PORTFOLIO_CPP_EDITOR_API UEx_Asset_Factory : public UFactory
{
	GENERATED_BODY()
	
public:
	UEx_Asset_Factory();

	virtual UObject* FactoryCreateNew(UClass* InClass, UObject* InParent, FName InName, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;

};

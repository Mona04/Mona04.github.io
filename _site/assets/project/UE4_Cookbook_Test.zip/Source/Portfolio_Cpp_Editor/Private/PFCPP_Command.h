#pragma once
#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"
#include "EditorStyleSet.h"


class PORTFOLIO_CPP_EDITOR_API FPFCPP_Command : public TCommands<FPFCPP_Command>
{
public:
	FPFCPP_Command();
	~FPFCPP_Command();

	virtual void RegisterCommands() override;
		
public:
	TSharedPtr<FUICommandInfo> mybutton;
};

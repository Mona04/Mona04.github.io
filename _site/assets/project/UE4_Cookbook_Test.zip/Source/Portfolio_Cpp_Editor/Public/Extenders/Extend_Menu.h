#pragma once

#include "Extend_Interface.h"

class PORTFOLIO_CPP_EDITOR_API FExtend_Menu : public Extend_Interface
{
public:
	virtual void StartupModule(TSharedPtr<FExtensibilityManager> manager, TSharedPtr<FUICommandList> cmdList) override;
	virtual void ShutdownModule() override;

	void AddExtension(FMenuBuilder& builder);

private:
	TSharedPtr<FExtender> extender;
	TSharedPtr<const FExtensionBase> extension;
};

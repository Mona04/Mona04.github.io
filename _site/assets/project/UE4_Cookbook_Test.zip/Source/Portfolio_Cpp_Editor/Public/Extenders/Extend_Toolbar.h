#pragma once

#include "Extend_Interface.h"

class PORTFOLIO_CPP_EDITOR_API FExtend_Toolbar : public Extend_Interface
{
public:
	FExtend_Toolbar();
	~FExtend_Toolbar();

	virtual void StartupModule(TSharedPtr<FExtensibilityManager> manager, TSharedPtr<FUICommandList> cmdList) override;
	virtual void ShutdownModule() override;

	void AddExtension(FToolBarBuilder& builder);

public:
	void MyButton_Clicked();

private:
	TSharedPtr<FExtender> extender;
	TSharedPtr<const FExtensionBase> extension;
};

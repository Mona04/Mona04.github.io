#pragma once
#include "CoreMinimal.h"

#include "UnrealEd.h"
#include "Interfaces/IMainFrameModule.h"
#include "LevelEditor.h"

class PORTFOLIO_CPP_EDITOR_API Extend_Interface
{
public:
	virtual void StartupModule(TSharedPtr<FExtensibilityManager> manager, TSharedPtr<FUICommandList> cmdList) = 0;
	virtual void ShutdownModule() = 0;
};
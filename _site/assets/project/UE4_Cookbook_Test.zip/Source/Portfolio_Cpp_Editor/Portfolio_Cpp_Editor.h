#pragma once

#include "CoreMinimal.h"
#include "PFCPP_Command.h"
#include "Extenders/Extend_Toolbar.h"
#include "Extenders/Extend_Menu.h"
#include "Assets/Regist_Asset.h"
#include "Commands/Regist_Cmd.h"
#include "Details/Detail_Ex_Object.h"

class FPFCppEditorModule : public FDefaultModuleImpl
{
	virtual bool IsGameModule() const override
	{
		return true;
	}

	virtual void StartupModule() override
	{
		FPFCPP_Command::Register();
		
		FLevelEditorModule& level_module = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
		TSharedPtr<FUICommandList> cmdList = MakeShareable(new FUICommandList());
		ex_toolbar.StartupModule(level_module.GetToolBarExtensibilityManager(), cmdList);
		ex_menu.StartupModule(level_module.GetMenuExtensibilityManager(), cmdList);		
		cmdList->MapAction(
			FPFCPP_Command::Get().mybutton,
			FExecuteAction::CreateRaw(&ex_toolbar, &FExtend_Toolbar::MyButton_Clicked),
			FCanExecuteAction());

		FPropertyEditorModule& property_module = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
		Detail_Ex_Object::StartupModule(property_module);

		Regist_Asset::StartupModule();
		Regist_Cmd::StartupModule();
	}

	virtual void ShutdownModule() override
	{
		ex_toolbar.ShutdownModule();
		ex_menu.ShutdownModule();

		FPropertyEditorModule& property_module = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
		Detail_Ex_Object::ShutdownModule(property_module);

		Regist_Asset::ShutdownModule();
		Regist_Cmd::ShutdownModule();		
	}

private:
	FExtend_Toolbar ex_toolbar;
	FExtend_Menu ex_menu;
};
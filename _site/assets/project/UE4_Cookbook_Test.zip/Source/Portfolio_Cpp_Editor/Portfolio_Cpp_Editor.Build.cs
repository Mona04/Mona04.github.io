using UnrealBuildTool;

public class Portfolio_Cpp_Editor : ModuleRules
{
	public Portfolio_Cpp_Editor(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[] {
			"Core", "CoreUObject", "Engine", "InputCore",
			"RHI", "RenderCore", 
			"MainFrame", "Slate", "SlateCore", "AppFramework", 
			"EditorStyle", "PropertyEditor"
		});
		PublicDependencyModuleNames.AddRange(new string[] {
			"Portfolio_Cpp"
		});
		PrivateDependencyModuleNames.AddRange(new string[] {
			"UnrealEd"
		});
		PublicIncludePaths.Add(ModuleDirectory);
	}
}
